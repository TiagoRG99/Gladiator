 font - LondrinaSolid-Regular
http://www.dafont.com/londrina.font